package com.example.movie_dir.Utils;

public class Constants {
    public final static String URL_LEFT = "http://www.omdbapi.com/?s=";
    public final static String URL_RIGHT = "&page=2&apikey=663f8d89";
    public final static String URL = "http://www.omdbapi.com/?i=";
    public final static String id = "&apikey=663f8d89";
}
